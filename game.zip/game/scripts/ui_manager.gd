extends Control

@onready var interaction_label: Label = find_child("InteractionLabel", true, false) as Label
@onready var interaction_panel: PanelContainer = find_child("InteractionPanel", true, false) as PanelContainer
@onready var objective_label: Label = find_child("ObjectiveLabel", true, false) as Label
@onready var level_label: Label = find_child("LevelLabel", true, false) as Label
@onready var xp_bar: ProgressBar = find_child("XPProgressBar", true, false) as ProgressBar
@onready var xp_text: Label = find_child("XPTextLabel", true, false) as Label
@onready var toast_container: VBoxContainer = find_child("ToastContainer", true, false) as VBoxContainer

# Dialogue UI
@onready var dialogue_panel: PanelContainer = find_child("DialoguePanel", true, false) as PanelContainer
@onready var speaker_label: Label = find_child("SpeakerLabel", true, false) as Label
@onready var dialogue_label: Label = find_child("DialogueLabel", true, false) as Label
@onready var next_button: Button = find_child("NextButton", true, false) as Button

# Pause Menu
@onready var pause_menu: Control = $PauseMenu
@onready var resume_button: Button = find_child("ResumeButton", true, false) as Button
@onready var save_button: Button = find_child("SaveButton", true, false) as Button
@onready var load_button: Button = find_child("LoadButton", true, false) as Button
@onready var settings_button: Button = find_child("SettingsButton", true, false) as Button
@onready var menu_button: Button = find_child("MenuButton", true, false) as Button
@onready var quit_button: Button = find_child("QuitButton", true, false) as Button

var current_dialogue_lines: Array = []
var dialogue_index: int = 0


func _ready() -> void:
	# Connect to GameManager signals
	GameManager.interaction_available.connect(_on_interaction_available)
	GameManager.interaction_unavailable.connect(_on_interaction_unavailable)
	GameManager.notification_posted.connect(_on_notification_posted)
	GameManager.dialogue_started.connect(_on_dialogue_started)
	GameManager.dialogue_ended.connect(_on_dialogue_ended)
	GameManager.objective_updated.connect(_on_objective_updated)
	GameManager.stats_updated.connect(_on_stats_updated)

	# Initial UI state
	interaction_panel.visible = false
	dialogue_panel.visible = false
	pause_menu.visible = false

	# Connect Pause Menu Buttons & Audio
	var btns = [resume_button, save_button, load_button, settings_button, menu_button, quit_button, next_button]
	for b in btns:
		if b:
			b.mouse_entered.connect(func(): GameManager.play_ui_sound("hover"))

	if resume_button:
		resume_button.pressed.connect(_on_resume_pressed)
	if save_button:
		save_button.pressed.connect(_on_save_pressed)
	if load_button:
		load_button.pressed.connect(_on_load_pressed)
	if settings_button:
		settings_button.pressed.connect(_on_settings_pressed)
	if menu_button:
		menu_button.pressed.connect(_on_menu_pressed)
	if quit_button:
		quit_button.pressed.connect(_on_quit_pressed)
	if next_button:
		next_button.pressed.connect(_on_next_dialogue_pressed)

	# Populate initial stats and objectives
	_on_stats_updated(MissionManager.level, MissionManager.xp, MissionManager.get_next_level_xp())
	_on_objective_updated(MissionManager.get_current_objective_text())


func _process(_delta: float) -> void:
	if pause_menu:
		pause_menu.visible = (GameManager.current_state == GameManager.GameState.PAUSED)


func _on_interaction_available(text: String) -> void:
	if interaction_label and interaction_panel:
		interaction_label.text = text
		interaction_panel.visible = true


func _on_interaction_unavailable() -> void:
	if interaction_panel:
		interaction_panel.visible = false


func _on_objective_updated(text: String) -> void:
	if objective_label:
		objective_label.text = text


func _on_stats_updated(lvl: int, current_xp: int, next_xp: int) -> void:
	if level_label:
		level_label.text = "Level " + str(lvl)
	if xp_bar:
		xp_bar.max_value = next_xp
		xp_bar.value = current_xp
	if xp_text:
		xp_text.text = str(current_xp) + " / " + str(next_xp) + " XP"


func _on_notification_posted(message: String) -> void:
	if not toast_container:
		return
	var toast = Label.new()
	toast.text = message
	toast.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT
	toast.add_theme_color_override("font_color", Color(1.0, 0.92, 0.45, 1.0))
	toast_container.add_child(toast)

	var tween = create_tween()
	tween.tween_interval(3.0)
	tween.tween_property(toast, "modulate:a", 0.0, 0.8)
	tween.tween_callback(toast.queue_free)


func _on_dialogue_started(speaker: String, lines: Array) -> void:
	current_dialogue_lines = lines
	dialogue_index = 0
	if speaker_label:
		speaker_label.text = speaker
	if dialogue_panel:
		dialogue_panel.visible = true
	_show_current_dialogue_line()


func _show_current_dialogue_line() -> void:
	if dialogue_index < current_dialogue_lines.size():
		if dialogue_label:
			dialogue_label.text = current_dialogue_lines[dialogue_index]
		if next_button:
			if dialogue_index == current_dialogue_lines.size() - 1:
				next_button.text = "Close [E]"
			else:
				next_button.text = "Next [E]"
	else:
		_on_dialogue_ended()


func _on_next_dialogue_pressed() -> void:
	dialogue_index += 1
	if dialogue_index < current_dialogue_lines.size():
		_show_current_dialogue_line()
	else:
		GameManager.end_dialogue()


func _on_dialogue_ended() -> void:
	if dialogue_panel:
		dialogue_panel.visible = false


func _on_resume_pressed() -> void:
	GameManager.play_ui_sound("click")
	GameManager.change_state(GameManager.GameState.PLAYING)


func _on_save_pressed() -> void:
	GameManager.play_ui_sound("click")
	SaveManager.save_game()


func _on_load_pressed() -> void:
	GameManager.play_ui_sound("click")
	SaveManager.load_game()


func _on_settings_pressed() -> void:
	GameManager.play_ui_sound("click")
	var settings_dialog = find_child("PauseSettingsModal", true, false)
	if settings_dialog:
		settings_dialog.visible = not settings_dialog.visible


func _on_menu_pressed() -> void:
	GameManager.play_ui_sound("click")
	GameManager.return_to_main_menu()


func _on_quit_pressed() -> void:
	GameManager.play_ui_sound("click")
	get_tree().quit()
